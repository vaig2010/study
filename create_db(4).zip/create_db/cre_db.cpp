#include "cre_db.h"
//-------------------------
extern QSqlDatabase db;

cre_db::cre_db(QWidget *parent) :
    QMainWindow(parent)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    frm_cre_db();
}

//-------------------------

cre_db::~cre_db()
{
    db.close();
}

int cre_db::frm_cre_db()
{
    QGridLayout *gl = new QGridLayout;

    pb_cre = new QPushButton("Создание");
    gl->addWidget(pb_cre,0,0,1,1);
    connect(pb_cre, SIGNAL(clicked()), this, SLOT(pb_cre_click()));

    pb_view = new QPushButton("Просмотр");
    gl->addWidget(pb_view,0,1,1,1);
    connect(pb_view, SIGNAL(clicked()), this, SLOT(pb_view_click()));

    pb_drop = new QPushButton("Удаление");
    gl->addWidget(pb_drop,0,2,1,1);
    connect(pb_drop, SIGNAL(clicked()), this, SLOT(pb_drop_click()));



    te_view = new QTextEdit;
    gl->addWidget(te_view, 1,0,10,6);

    QWidget *wgt = new QWidget(this);
    wgt->setLayout(gl);
    this->setCentralWidget(wgt);


    this->setWindowTitle("База данных");
    this->move(300, 300);
    this->setMaximumHeight(800);
    this->setMaximumWidth(800);
    this->setMinimumHeight(400);
    this->setMinimumWidth(400);



    return 0;
}

int cre_db::pb_cre_click()
{
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    strsql = "create database test2; use test2;"
            "CREATE TABLE `nauch_ruk` ("
            "`nauch_ruk_id` bigint(20) NOT NULL AUTO_INCREMENT,"

            "`nauch_ruk_fam` varchar(64) NOT NULL,"
            "`nauch_ruk_im_otch` varchar(64) NULL,"
            "`nauch_step` varchar(32) NOT NULL,"
            "`dolzhnost` varchar(32) NOT NULL,"
            "`kaf_id` bigint(20) NOT NULL,"
            "PRIMARY KEY (`nauch_ruk_id`)"
            ");"
            "CREATE TABLE `aspirant` ("
            "`aspirant_id` bigint(20) NOT NULL AUTO_INCREMENT,"
            "`aspirant_fam` varchar(64) NOT NULL,"
            "`aspirant_im_otch` varchar(64) NOT NULL,"
            "`obrazovanie` varchar(32) NOT NULL,"
            "`nauch_special` varchar(32) NOT NULL,"
            "`nauch_ruk_id` bigint(20) NOT NULL,"
            "PRIMARY KEY (`aspirant_id`)"
            ");"
            "CREATE TABLE `kafedra` ("
            "`kafedra_id` bigint(20) NOT NULL AUTO_INCREMENT,"
            "`nazvanie` varchar(64) NOT NULL"
            "PRIMARY KEY (`kafedra_id`));";
    quer->exec(strsql);
    if (quer->isActive())
    {
        QMessageBox::information(this,"Сообщение","запрос create успешен",QMessageBox::Yes);
    }
    else
    {
        QMessageBox::information(this,"Сообщение","запрос create неуспешен",QMessageBox::Yes);
    }
    return 0;
}

int cre_db::pb_drop_click()
{
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    strsql = "drop database test2";

    quer->exec(strsql);
    if (quer->isActive())
    {
        QMessageBox::information(this,"Сообщение","запрос drop успешен",QMessageBox::Yes);
    }
    else
    {
        QMessageBox::information(this,"Сообщение","запрос drop неуспешен",QMessageBox::Yes);
    }
    return 0;
}

int cre_db::pb_view_click()
{
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);

    te_view->append("\nСписок баз:");
    strsql = "show databases;";

    quer->exec(strsql);

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(quer->value(0).toString());
        }
    }
    quer->exec("use test2;");
    te_view->append("\nСписок таблиц:");
    quer->exec("show tables;");

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(quer->value(0).toString());
        }
    }

    te_view->append("\nОписание таблицы aspirant:");
    quer->exec("describe aspirant;");

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(QString("%1\t%2\t%3\t%4\t%5\t%6").arg(
                                quer->value(0).toString(), quer->value(1).toString(), quer->value(2).toString(),
                                quer->value(3).toString(), quer->value(4).toString(), quer->value(5).toString()));
        }
    }
    te_view->append("\nОписание таблицы nauch_ruk:");
    quer->exec("describe nauch_ruk;");
    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(QString("%1\t%2\t%3\t%4\t%5\t%6").arg(
                                quer->value(0).toString(), quer->value(1).toString(), quer->value(2).toString(),
                                quer->value(3).toString(), quer->value(4).toString(), quer->value(5).toString()));
        }
    }


    return 0;
}
