#ifndef CRE_USER_H
#define CRE_USER_H

#include <QMainWindow>
#include <QTextCodec>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QStatusBar>
#include <QSqlDatabase>
#include <QCheckBox>


class cre_user : public QMainWindow
{
    Q_OBJECT

public:
    cre_user(QWidget *parent = 0);
    ~cre_user();
    int frm_conn();
    QLineEdit *le_login;
    QLineEdit *le_pass;
    QLineEdit *le_rights;
    QPushButton *pb_conn;
    QCheckBox *cb_conn;
public slots:
    int le_edit();
    int pb_conn_click();
    int cb_conn_click();
};


#endif // CRE_USER_H


