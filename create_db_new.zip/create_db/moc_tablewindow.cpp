/****************************************************************************
** Meta object code from reading C++ file 'tablewindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "tablewindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tablewindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TableWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x08,
      41,   12,   12,   12, 0x08,
      64,   12,   12,   12, 0x08,
      90,   12,   12,   12, 0x08,
     130,  113,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TableWindow[] = {
    "TableWindow\0\0on_btnLoadVwTable_clicked()\0"
    "on_btnAddRow_clicked()\0on_btnDeleteRow_clicked()\0"
    "on_btnSearch_clicked()\0current,previous\0"
    "on_listWidget_currentItemChanged(QListWidgetItem*,QListWidgetItem*)\0"
};

void TableWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TableWindow *_t = static_cast<TableWindow *>(_o);
        switch (_id) {
        case 0: _t->on_btnLoadVwTable_clicked(); break;
        case 1: _t->on_btnAddRow_clicked(); break;
        case 2: _t->on_btnDeleteRow_clicked(); break;
        case 3: _t->on_btnSearch_clicked(); break;
        case 4: _t->on_listWidget_currentItemChanged((*reinterpret_cast< QListWidgetItem*(*)>(_a[1])),(*reinterpret_cast< QListWidgetItem*(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TableWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TableWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_TableWindow,
      qt_meta_data_TableWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TableWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TableWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TableWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TableWindow))
        return static_cast<void*>(const_cast< TableWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int TableWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
