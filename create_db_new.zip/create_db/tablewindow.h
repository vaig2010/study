#ifndef TABLEWINDOW_H
#define TABLEWINDOW_H

#include <QDialog>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QTextCodec>
#include <QListWidgetItem>
#include <QString>
#include <QMessageBox>
#include <QTableView>
#include <QComboBox>
#include <QStringList>
#include <QSqlRecord>
#include <QInputDialog>

namespace Ui {
class TableWindow;
}

class TableWindow : public QDialog
{
    Q_OBJECT

public:
    explicit TableWindow(QWidget *parent = 0);
    ~TableWindow();
    void reloadTable();
    void mainfrm();
    QString itemstr;
    QSqlTableModel *model;

private slots:
    void on_btnLoadVwTable_clicked();

    void on_btnAddRow_clicked();

    void on_btnDeleteRow_clicked();

    void on_btnSearch_clicked();

    void on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous);

private:
    Ui::TableWindow *ui;
};

#endif // TABLEWINDOW_H
