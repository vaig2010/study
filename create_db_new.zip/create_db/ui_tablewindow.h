/********************************************************************************
** Form generated from reading UI file 'tablewindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLEWINDOW_H
#define UI_TABLEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QTableView>

QT_BEGIN_NAMESPACE

class Ui_TableWindow
{
public:
    QTableView *tableView;
    QPushButton *btnLoadVwTable;
    QListWidget *listWidget;
    QPushButton *btnAddRow;
    QPushButton *btnDeleteRow;
    QLabel *label;
    QPushButton *btnSearch;

    void setupUi(QDialog *TableWindow)
    {
        if (TableWindow->objectName().isEmpty())
            TableWindow->setObjectName(QString::fromUtf8("TableWindow"));
        TableWindow->resize(979, 404);
        tableView = new QTableView(TableWindow);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(190, 50, 771, 301));
        btnLoadVwTable = new QPushButton(TableWindow);
        btnLoadVwTable->setObjectName(QString::fromUtf8("btnLoadVwTable"));
        btnLoadVwTable->setGeometry(QRect(50, 360, 100, 23));
        listWidget = new QListWidget(TableWindow);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(20, 50, 161, 301));
        btnAddRow = new QPushButton(TableWindow);
        btnAddRow->setObjectName(QString::fromUtf8("btnAddRow"));
        btnAddRow->setGeometry(QRect(200, 360, 100, 23));
        btnDeleteRow = new QPushButton(TableWindow);
        btnDeleteRow->setObjectName(QString::fromUtf8("btnDeleteRow"));
        btnDeleteRow->setGeometry(QRect(500, 360, 100, 23));
        label = new QLabel(TableWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 20, 101, 16));
        btnSearch = new QPushButton(TableWindow);
        btnSearch->setObjectName(QString::fromUtf8("btnSearch"));
        btnSearch->setGeometry(QRect(370, 360, 100, 23));

        retranslateUi(TableWindow);

        QMetaObject::connectSlotsByName(TableWindow);
    } // setupUi

    void retranslateUi(QDialog *TableWindow)
    {
        TableWindow->setWindowTitle(QApplication::translate("TableWindow", "\320\237\321\200\320\276\321\201\320\274\320\276\321\202\321\200 \321\202\320\260\320\261\320\273\320\270\321\206", 0, QApplication::UnicodeUTF8));
        btnLoadVwTable->setText(QApplication::translate("TableWindow", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214", 0, QApplication::UnicodeUTF8));
        btnAddRow->setText(QApplication::translate("TableWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", 0, QApplication::UnicodeUTF8));
        btnDeleteRow->setText(QApplication::translate("TableWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("TableWindow", "\320\241\320\277\320\270\321\201\320\276\320\272 \321\202\320\260\320\261\320\273\320\270\321\206", 0, QApplication::UnicodeUTF8));
        btnSearch->setText(QApplication::translate("TableWindow", "\320\235\320\260\320\271\321\202\320\270", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TableWindow: public Ui_TableWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLEWINDOW_H
