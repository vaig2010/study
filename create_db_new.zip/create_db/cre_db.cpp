#include "cre_db.h"
#include "tablewindow.h"
//-------------------------
extern QSqlDatabase db;

cre_db::cre_db(QWidget *parent) :
    QMainWindow(parent)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    frm_cre_db();
}

//-------------------------



int cre_db::frm_cre_db()
{
    QGridLayout *gl = new QGridLayout;

    pb_cre = new QPushButton("Создать");
    gl->addWidget(pb_cre,0,0,1,1);
    connect(pb_cre, SIGNAL(clicked()), this, SLOT(pb_cre_click()));

    pb_view = new QPushButton("Просмотр");
    gl->addWidget(pb_view,0,1,1,1);
    connect(pb_view, SIGNAL(clicked()), this, SLOT(pb_view_click()));

    pb_drop = new QPushButton("Удалить");
    gl->addWidget(pb_drop,0,2,1,1);
    connect(pb_drop, SIGNAL(clicked()), this, SLOT(pb_drop_click()));


    QWidget *wgt = new QWidget(this);
    wgt->setLayout(gl);
    this->setCentralWidget(wgt);


    this->setWindowTitle("База данных");
    this->move(300, 300);
    this->setMaximumHeight(800);
    this->setMaximumWidth(800);
    this->setMinimumHeight(100);
    this->setMinimumWidth(400);

    return 0;
}

int cre_db::pb_cre_click()
{

    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    quer->exec("create database AspirKafedri;");
    quer->exec("use AspirKafedri;");

    strsql = "CREATE TABLE `nauch_ruk` ("
            "`nauch_ruk_id` bigint(20) NOT NULL AUTO_INCREMENT,"
            "`nauch_ruk_fam` varchar(64) NOT NULL,"
            "`nauch_ruk_im_otch` varchar(64) NULL,"
            "`nauch_step` varchar(32) NOT NULL,"
            "`dolzhnost` varchar(32) NOT NULL,"
            "`kaf_id` bigint(20) NOT NULL,"
            "PRIMARY KEY (`nauch_ruk_id`)"
            ");"
            "CREATE TABLE `aspirant` ("
            "`aspirant_id` bigint(20) NOT NULL AUTO_INCREMENT,"
            "`aspirant_fam` varchar(64) NOT NULL,"
            "`aspirant_im_otch` varchar(64) NOT NULL,"
            "`obrazovanie` varchar(32) NOT NULL,"
            "`nauch_special` varchar(32) NOT NULL,"
            "`nauch_ruk_id` bigint(20) NOT NULL,"
            "PRIMARY KEY (`aspirant_id`)"
            ");"
            "CREATE TABLE `kafedra` ("
                        "`kafedra_id` bigint(20) NOT NULL AUTO_INCREMENT,"
                        "`nazvanie` varchar(64) NOT NULL,"
                        "PRIMARY KEY (`kafedra_id`));";
    quer->exec(strsql);
    quer->exec("use AspirKafedri;");
    strsql = "INSERT INTO nauch_ruk (nauch_ruk_fam, nauch_ruk_im_otch, nauch_step, dolzhnost, kaf_id) VALUES (\"Иванов\",\"Иван Иванович\", \"Кандидат наук\", \"Профессор\", 1);";
    quer->exec(strsql);
    strsql = "INSERT INTO aspirant (aspirant_fam, aspirant_im_otch, obrazovanie, nauch_special, nauch_ruk_id) VALUES (\"Иванов\",\"Иван Иванович\", \"Аспирантура\", \"Аспирант\", 1);";
    quer->exec(strsql);
    strsql = "INSERT INTO kafedra (nazvanie) VALUES (\"Кафедра информационных технологий\");";
    quer->exec(strsql);
    if (quer->isActive())
    {
        QMessageBox::information(this,"Сообщение","База данных успешно создана",QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(this,"Сообщение","Ошибка! База данных не создана",QMessageBox::Ok);
    }
    return 0;
}

int cre_db::pb_drop_click()
{
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    strsql = "drop database AspirKafedri;";

    quer->exec(strsql);
    if (quer->isActive())
    {
        QMessageBox::information(this,"Сообщение","База данных удалена",QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(this,"Сообщение","Не удалось удалить базу данных",QMessageBox::Ok);
    }
    return 0;
}

int cre_db::pb_view_click()
{
    QSqlQuery *quer;
    QString strsql;

    quer = new QSqlQuery(db);
    quer->exec("use AspirKafedri;");
    if (quer->isActive())
    {
        TableWindow wind;
        wind.setModal(true);
        wind.exec();
    }
    else
    {
        QMessageBox::information(this,"Сообщение","База данных ещё не создана",QMessageBox::Ok);
    }

    /*
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);

    te_view->append("\nСписок баз:");
    strsql = "show databases;";

    quer->exec(strsql);

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(quer->value(0).toString());
        }
    }
    quer->exec("use test2;");
    te_view->append("\nСписок таблиц:");
    quer->exec("show tables;");

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(quer->value(0).toString());
        }
    }

    te_view->append("\nОписание таблицы aspirant:");
    quer->exec("describe aspirant;");

    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(QString("%1\t%2\t%3\t%4\t%5\t%6").arg(
                                quer->value(0).toString(), quer->value(1).toString(), quer->value(2).toString(),
                                quer->value(3).toString(), quer->value(4).toString(), quer->value(5).toString()));
        }
    }
    te_view->append("\nОписание таблицы nauch_ruk:");
    quer->exec("describe nauch_ruk;");
    if(quer->isActive())
    {
        while(quer->next())
        {
            te_view->append(QString("%1\t%2\t%3\t%4\t%5\t%6").arg(
                                quer->value(0).toString(), quer->value(1).toString(), quer->value(2).toString(),
                                quer->value(3).toString(), quer->value(4).toString(), quer->value(5).toString()));
        }
    }*/


    return 0;
}
cre_db::~cre_db()
{
    db.close();
}
