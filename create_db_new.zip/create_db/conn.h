#ifndef CONN_H
#define CONN_H

#include <QMainWindow>
#include <QTextCodec>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QStatusBar>
#include <QSqlDatabase>
#include <QCheckBox>

class conn : public QMainWindow
{
    Q_OBJECT

public:
    conn(QWidget *parent = 0);
    ~conn();
    int frm_conn();
    QLineEdit *le_login;
    QLineEdit *le_pass;
    QPushButton *pb_conn;
public slots:
    int le_edit();
    int pb_conn_click();
};


#endif // CONN_H
