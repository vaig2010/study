/****************************************************************************
** Meta object code from reading C++ file 'cre_db.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "cre_db.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'cre_db.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_cre_db[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,    7,    8,    7, 0x0a,
      25,    7,    8,    7, 0x0a,
      40,    7,    8,    7, 0x0a,
      56,    7,    8,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_cre_db[] = {
    "cre_db\0\0int\0frm_cre_db()\0pb_cre_click()\0"
    "pb_drop_click()\0pb_view_click()\0"
};

void cre_db::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        cre_db *_t = static_cast<cre_db *>(_o);
        switch (_id) {
        case 0: { int _r = _t->frm_cre_db();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 1: { int _r = _t->pb_cre_click();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 2: { int _r = _t->pb_drop_click();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 3: { int _r = _t->pb_view_click();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData cre_db::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject cre_db::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_cre_db,
      qt_meta_data_cre_db, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &cre_db::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *cre_db::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *cre_db::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_cre_db))
        return static_cast<void*>(const_cast< cre_db*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int cre_db::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
