#include "tablewindow.h"
#include "ui_tablewindow.h"
extern QSqlDatabase db;

TableWindow::TableWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TableWindow)
{
    ui->setupUi(this);
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    reloadTable();
    mainfrm();
}

void TableWindow::mainfrm()
{
    ui->tableView->setSortingEnabled(true);
    ui->listWidget->clear();
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    strsql = "show tables;";
    quer->exec(strsql);
    if(quer->isActive())
    {
        while(quer->next())
            ui->listWidget->addItem(quer->value(0).toString());
    }
}

TableWindow::~TableWindow()
{
    delete ui;
}

void TableWindow::reloadTable()
{
    model = new QSqlTableModel();
    model->setTable(itemstr);
    model->select();
    ui->tableView->setModel(model);
    ui->tableView->resizeColumnsToContents();
}

void TableWindow::on_btnLoadVwTable_clicked()
{

    QListWidgetItem *itm = ui->listWidget->currentItem();
    if (itm == 0x0)
    {
        QMessageBox::information(this,"Сообщение","Таблица не выбрана",QMessageBox::Ok);
    }
    else
    {
        itemstr = itm->text();
        reloadTable();
    }
}

void TableWindow::on_btnAddRow_clicked()
{
    QSqlQuery *quer;
    QString strsql;
    quer = new QSqlQuery(db);
    if (itemstr == "nauch_ruk")
    {
        strsql = "INSERT INTO nauch_ruk (nauch_ruk_fam, nauch_ruk_im_otch, nauch_step, dolzhnost, kaf_id) VALUES (\"\",\"\",\"\",\"\",0);";
        quer->exec(strsql);
    }
    else if (itemstr == "aspirant")
    {
        strsql = "INSERT INTO aspirant (aspirant_fam, aspirant_im_otch, obrazovanie, nauch_special, nauch_ruk_id) VALUES (\"\",\"\",\"\",\"\",0);";
        quer->exec(strsql);
    }
    else
        QMessageBox::information(this,"Сообщение","Таблица не выбрана",QMessageBox::Ok);

    reloadTable();
}

void TableWindow::on_btnDeleteRow_clicked()
{
    QSqlQuery *quer;
    quer = new QSqlQuery(db);
    int rowID = ui->tableView->currentIndex().row();
    int ind = ui->tableView->model()->index(rowID,0).data().toInt();
    QString strsql;
    strsql = QString("delete from %1 where %1_id = %2;").arg(itemstr, QString::number(ind));
    quer->exec(strsql);
    reloadTable();
}

void TableWindow::on_btnSearch_clicked()
{
    QStringList rows;
    for (int i=0;i<model->columnCount(); i++ )
    {
        QString s= model->record().fieldName(i);
        rows<<(s);
    }
    bool Ok;
    QString chrows = QInputDialog::getItem(this, "Выбор столбца",
                                       tr("Имя столбца"), rows, 0, false, &Ok);

    QString find= QInputDialog::getText(0,"Ввод","Введите ключевое слово",
    QLineEdit::Normal,"",&Ok);

    if (chrows != "" && find != "")
    {
        QString strok = QString("%1 = \"%2\"").arg(chrows, find);
        model->setFilter(strok);
        model->setSort(0, Qt::AscendingOrder);
        model->select();
    }
    else
    {
        QMessageBox::information(this,"Сообщение","Введите правильные поисковые данные",QMessageBox::Ok);
    }
}

void TableWindow::on_listWidget_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous)
{
    QListWidgetItem *itm = ui->listWidget->currentItem();
    if (itm == 0x0)
    {
        QMessageBox::information(this,"Сообщение","Таблица не выбрана",QMessageBox::Ok);
    }
    else
    {
        itemstr = itm->text();
        reloadTable();
    }
}
