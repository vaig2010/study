#include "cre_user.h"
#include "conn.h"
#include "cre_db.h"



QSqlDatabase db;
cre_user::cre_user(QWidget *parent) :
    QMainWindow(parent)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    frm_conn();
}

int cre_user::frm_conn()
{
    QGridLayout *gl = new QGridLayout;

    QLabel *lb_login = new QLabel("Логин");
    gl->addWidget(lb_login,0,0,1,1);

    le_login = new QLineEdit;
    gl->addWidget(le_login,0,1,1,1);

    QLabel *lb_pass = new QLabel("Пароль");
    gl->addWidget(lb_pass,1,0,1,1);

    le_pass = new QLineEdit;
    gl->addWidget(le_pass,1,1,1,1);

    QLabel *lb_rights = new QLabel("Права");
    gl->addWidget(lb_rights,2,0,1,1);

    le_rights = new QLineEdit;
    gl->addWidget(le_rights,2,1,1,1);
    le_rights->setText("ALL");

    pb_conn = new QPushButton("Создать");
    gl->addWidget(pb_conn,3,0,1,1);


    cb_conn = new QCheckBox;
    gl->addWidget(cb_conn,1,2,1,1);


    pb_conn->setShortcut(QKeySequence(Qt::Key_Return));
    pb_conn->setEnabled(true);



    this->setWindowTitle("Создание пользователя");
    this->move(300, 300);
    this->setMaximumHeight(800);
    this->setMaximumWidth(800);
    this->setMinimumHeight(200);
    this->setMinimumWidth(200);
    /*
    this->setTabOrder(le_login, le_pass);
    this->setTabOrder(le_pass, pb_conn);
    this->setTabOrder(pb_conn, le_login);
    */
    connect(pb_conn, SIGNAL(clicked()), this, SLOT(pb_conn_click()));
    connect(cb_conn, SIGNAL(clicked()), this, SLOT(cb_conn_click()));

    connect(le_pass, SIGNAL(editingFinished()), this, SLOT(le_edit()));
    connect(le_login, SIGNAL(editingFinished()), this, SLOT(le_edit()));

    QWidget *wgt = new QWidget(this);
    wgt->setLayout(gl);
    this->setCentralWidget(wgt);

    return 0;
}

int cre_user::cb_conn_click()
{
    if (cb_conn->isChecked())
        le_pass->setEchoMode(QLineEdit::Password);
    else
        le_pass->setEchoMode(QLineEdit::Normal);

    return 0;
}

int cre_user::le_edit()
{
//    if ((le_login->text() != "") && (le_pass->text() != ""))
//        pb_conn->setEnabled(true);
//    else
//        pb_conn->setEnabled(false);
//    return 0;
}

int cre_user::pb_conn_click()
{
    db = QSqlDatabase::addDatabase("QMYSQL", "mydb");
    db.setHostName("localhost");
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("rootsqladm");

    if (db.open())
    {
        QMessageBox::information(this,"Сообщение","Соединение установлено",QMessageBox::Yes);

        QSqlQuery *quer;
        QString strsql;
        quer = new QSqlQuery(db);
        strsql = "CREATE USER '" + le_login->text() + "'@'localhost' IDENTIFIED BY '" + le_pass->text() + "';";
        quer->exec(strsql);
        strsql = "GRANT " + le_rights->text() + " ON vaskin.* TO " +
                le_login->text() + "@localhost IDENTIFIED BY '" + le_pass->text() + "';";

        quer->exec(strsql);

        if (quer->isActive())
        {
            QMessageBox::information(this,"Сообщение","Пользователь " + le_login->text()
                                     + " успешно создан",QMessageBox::Yes);
            //strsql = "show grants for " + le_login->text() + "@localhost;";
            conn *frm = new conn;
            frm->show();
            this->hide();


        }
        else
        {
            QMessageBox::information(this,"Сообщение","Не удалось создать пользователя",QMessageBox::Yes);
        }
        return 0;
    }
    else
    {
        QMessageBox::information(this,"Сообщение","Соединение не установлено",QMessageBox::Yes);
    }
    return 0;

}

cre_user::~cre_user()
{
    db.close();
}
