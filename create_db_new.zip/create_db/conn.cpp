#include "conn.h"
#include "cre_db.h"
QSqlDatabase db;

conn::conn(QWidget *parent)
    : QMainWindow(parent)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    frm_conn();
}
int conn::frm_conn()
{
    QGridLayout *gl = new QGridLayout;

    QLabel *lb_login = new QLabel("Логин");
    gl->addWidget(lb_login,0,0,1,1);

    le_login = new QLineEdit;
    gl->addWidget(le_login,0,1,1,1);

    QLabel *lb_pass = new QLabel("Пароль");
    gl->addWidget(lb_pass,1,0,1,1);

    le_pass = new QLineEdit;
    gl->addWidget(le_pass,1,1,1,1);

    pb_conn = new QPushButton("Вход");
    gl->addWidget(pb_conn,2,1,1,1);

    le_pass->setEchoMode(QLineEdit::Password);
    le_pass->setFocus();

    pb_conn->setShortcut(QKeySequence(Qt::Key_Return));

    pb_conn->setEnabled(true);

    this->setWindowTitle("Вход");
    this->move(300, 300);
    this->setMaximumHeight(800);
    this->setMaximumWidth(800);
    this->setMinimumHeight(200);
    this->setMinimumWidth(200);
    /*
    this->setTabOrder(le_login, le_pass);
    this->setTabOrder(le_pass, pb_conn);
    this->setTabOrder(pb_conn, le_login);
    */
    connect(pb_conn, SIGNAL(clicked()), this, SLOT(pb_conn_click()));
    connect(le_pass, SIGNAL(editingFinished()), this, SLOT(le_edit()));
    connect(le_login, SIGNAL(editingFinished()), this, SLOT(le_edit()));

    QWidget *wgt = new QWidget(this);
    wgt->setLayout(gl);
    this->setCentralWidget(wgt);

    return 0;
}

int conn::le_edit()
{
//    if ((le_login->text() != "") && (le_pass->text() != ""))
//        pb_conn->setEnabled(true);
//    else
//        pb_conn->setEnabled(false);
    return 0;
}

int conn::pb_conn_click()
{
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setPort(3306);
    //le_login->text()
    db.setUserName("root");
    //le_pass->text()
    db.setPassword("rootsqladm");

    if (db.open())
    {
        QMessageBox::information(this,"Сообщение","Соединение установлено",QMessageBox::Ok);
        cre_db *frm = new cre_db;
        frm->show();
        this->hide();
    }
    else
    {
        QMessageBox::information(this,"Сообщение","Соединение не установлено",QMessageBox::Ok);
    }
    return 0;

}

conn::~conn()
{
    db.close();
}
