#ifndef CRE_DB_H
#define CRE_DB_H
#include <QMainWindow>
#include <QTextCodec>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QStatusBar>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTextEdit>
#include <QtGui>


class cre_db : public QMainWindow
{
    Q_OBJECT
public:
    explicit cre_db(QWidget *parent = 0);
    ~cre_db();
    QPushButton *pb_cre;
    QPushButton *pb_view;
    QPushButton *pb_drop;
//    QTextEdit *te_view;

signals:

public slots:
    int frm_cre_db();
    int pb_cre_click();
    int pb_drop_click();
    int pb_view_click();
};

#endif // CRE_DB_H
